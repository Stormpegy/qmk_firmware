Keyboard: Lily58  
Keys: Lily58 is 6×4+5keys column-staggered split keyboard.  
Layout: Swedish characters on main layer using tap dance. Built for Eurkey keyboard layout.  
Flash instructions: Flash using dfu, will req the hvp user space to compile.

> make lily58:hvp:dfu

Links:  
Github - https://github.com/qmk/qmk_firmware/tree/master/keyboards/lily58  
Eurkey layout - https://eurkey.steffen.bruentjen.eu/
