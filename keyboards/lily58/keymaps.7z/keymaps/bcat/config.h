#pragma once

#define EE_HANDS

/* Work around Elite-C v3 with broken VBUS detection. */
#define SPLIT_USB_DETECT
