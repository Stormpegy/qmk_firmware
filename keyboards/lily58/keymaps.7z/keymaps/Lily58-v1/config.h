
#pragma once

#define MASTER_LEFT

#define ENCODERS_PAD_A { F4 }
#define ENCODERS_PAD_B { F5 }
#define ENCODER_RESOLUTION 4

#define USE_SERIAL_PD2

#define TAPPING_TOGGLE 2
/* #define TAPPING_FORCE_HOLD
#define TAPPING_TERM 100 */
