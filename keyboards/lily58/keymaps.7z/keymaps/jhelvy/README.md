# jhelvy Keymap for [Lily58 Pro](https://github.com/kata0510/Lily58)

## Keymap

This is a custom keymap with the following layout:

<img src="https://github.com/jhelvy/qmkJsonConverter/raw/master/keymaps/lily58_rev1_jhelvy.png" width="800">
